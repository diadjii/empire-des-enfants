create trigger promotion
  after UPDATE
  on enseignant
  for each row
  begin 
if old.Ancien > 7 then 
update enseignant set Grade ="PR" where Numens = OLD.Numens;
end if;
end;


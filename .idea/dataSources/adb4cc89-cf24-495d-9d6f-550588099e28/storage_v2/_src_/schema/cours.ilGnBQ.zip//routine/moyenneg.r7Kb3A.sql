create function moyenneG(num int)
  returns float
  begin  declare v_moy float; select avg(note)  into v_moy from notes where Numetu =num; return v_moy; end;


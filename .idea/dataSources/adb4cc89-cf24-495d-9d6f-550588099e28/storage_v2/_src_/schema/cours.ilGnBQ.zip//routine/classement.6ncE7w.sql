create procedure classement()
  select moyenneG(Numetu) as moyenneGenerale,Numetu , Prenometu, Nometu from etudiant order By moyenneGenerale;

